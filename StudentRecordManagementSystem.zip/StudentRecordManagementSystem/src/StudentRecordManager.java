// StudentRecordManager.java
import java.io.*; // Import for file handling classes
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
// import java.util.stream.Collectors; // Not strictly needed for this version of save, but fine if present

public class StudentRecordManager {
    private Map<String, Student> students; // Using HashMap for efficient lookups
    private final String FILE_DELIMITER = ","; // Delimiter for CSV file format

    public StudentRecordManager() {
        this.students = new HashMap<>();
    }

    public boolean addStudent(Student student) {
        if (students.containsKey(student.getStudentId())) {
            System.out.println("Error: Student with ID " + student.getStudentId() + " already exists.");
            return false;
        }
        students.put(student.getStudentId(), student);
        System.out.println("Student added successfully: " + student.getName());
        return true;
    }

    public List<Student> viewAllStudents() {
        return new ArrayList<>(students.values()); // Return a copy of the list of students
    }

    public Student findStudentById(String studentId) {
        return students.get(studentId);
    }

    public boolean updateStudent(String studentId, String newName, int newAge, String newGrade) {
        Student student = students.get(studentId);
        if (student != null) {
            student.setName(newName);
            student.setAge(newAge);
            student.setGrade(newGrade);
            System.out.println("Student ID " + studentId + " updated successfully.");
            return true;
        } else {
            System.out.println("Error: Student with ID " + studentId + " not found for update.");
            return false;
        }
    }

    public boolean deleteStudent(String studentId) {
        if (students.containsKey(studentId)) {
            students.remove(studentId);
            System.out.println("Student ID " + studentId + " deleted successfully.");
            return true;
        } else {
            System.out.println("Error: Student with ID " + studentId + " not found for deletion.");
            return false;
        }
    }

    // --- File Handling Methods ---

    public void saveRecordsToFile(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Student student : students.values()) {
                writer.write(student.getStudentId() + FILE_DELIMITER +
                             student.getName() + FILE_DELIMITER +
                             student.getAge() + FILE_DELIMITER +
                             student.getGrade());
                writer.newLine(); // Writes a new line character
            }
            System.out.println("Student records saved to " + filename);
        } catch (IOException e) {
            System.err.println("Error saving records to file: " + e.getMessage());
        }
    }

    public void loadRecordsFromFile(String filename) {
        students.clear(); // Clear existing records before loading
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(FILE_DELIMITER);
                // Ensure the line has the expected number of parts (ID, Name, Age, Grade)
                if (parts.length == 4) {
                    try {
                        String id = parts[0];
                        String name = parts[1];
                        int age = Integer.parseInt(parts[2]); // Convert age string to int
                        String grade = parts[3];
                        Student student = new Student(id, name, age, grade);
                        students.put(id, student); // Add the loaded student to the map
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing age in line: " + line + ". Skipping this record. Error: " + e.getMessage());
                    }
                } else {
                    System.err.println("Skipping malformed line (incorrect number of parts): " + line);
                }
            }
            System.out.println("Student records loaded from " + filename);
        } catch (FileNotFoundException e) {
            System.out.println("No existing record file found: " + filename + ". Starting with an empty record set.");
        } catch (IOException e) {
            System.err.println("Error loading records from file: " + e.getMessage());
        }
    }
}