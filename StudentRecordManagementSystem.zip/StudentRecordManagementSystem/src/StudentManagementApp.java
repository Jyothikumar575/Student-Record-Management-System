
// StudentManagementApp.java
import java.util.List;
import java.util.Scanner;

public class StudentManagementApp {
    private static final String DATA_FILE = "students.txt";
    private static StudentRecordManager manager = new StudentRecordManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        manager.loadRecordsFromFile(DATA_FILE); // Load data on startup

        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = getIntegerInput(); // Use helper for robust integer input

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    viewAllStudents();
                    break;
                case 3:
                    updateStudent();
                    break;
                case 4:
                    deleteStudent();
                    break;
                case 5:
                    manager.saveRecordsToFile(DATA_FILE);
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println(); // Add a blank line for readability
        } while (choice != 5);

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("--- Student Record Management System ---");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Update Student");
        System.out.println("4. Delete Student");
        System.out.println("5. Exit");
    }

    private static void addStudent() {
        System.out.println("\n--- Add New Student ---");
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Student Age: ");
        int age = getIntegerInput();
        // Important: Consume the leftover newline character after reading the integer
        // This prevents the next nextLine() from reading an empty string immediately
        scanner.nextLine();
        System.out.print("Enter Student Grade (e.g., A, B, C): ");
        String grade = scanner.nextLine();

        Student newStudent = new Student(id, name, age, grade);
        manager.addStudent(newStudent);
    }

    private static void viewAllStudents() {
        System.out.println("\n--- All Student Records ---");
        List<Student> students = manager.viewAllStudents();
        if (students.isEmpty()) {
            System.out.println("No student records found.");
        } else {
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    private static void updateStudent() {
        System.out.println("\n--- Update Student ---");
        System.out.print("Enter Student ID to update: ");
        String id = scanner.nextLine();

        Student student = manager.findStudentById(id);
        if (student == null) {
            System.out.println("Student with ID " + id + " not found.");
            return;
        }

        System.out.println("Found Student: " + student);
        // Prompt for new values, allowing user to press Enter to keep current
        System.out.print("Enter new Name (or press Enter to keep current '" + student.getName() + "'): ");
        String newName = scanner.nextLine();
        if (newName.isEmpty()) {
            newName = student.getName(); // Use current name if input is empty
        }

        System.out.print("Enter new Age (or enter 0 to keep current '" + student.getAge() + "'): ");
        int newAge = getIntegerInput();
        scanner.nextLine(); // Consume newline after integer input
        if (newAge == 0) { // Assuming 0 is a sentinel value for "keep current" age
            newAge = student.getAge();
        }

        System.out.print("Enter new Grade (or press Enter to keep current '" + student.getGrade() + "'): ");
        String newGrade = scanner.nextLine();
        if (newGrade.isEmpty()) {
            newGrade = student.getGrade(); // Use current grade if input is empty
        }

        manager.updateStudent(id, newName, newAge, newGrade);
    }

    private static void deleteStudent() {
        System.out.println("\n--- Delete Student ---");
        System.out.print("Enter Student ID to delete: ");
        String id = scanner.nextLine();
        manager.deleteStudent(id);
    }

    // Helper method to get robust integer input, handling non-integer input
    private static int getIntegerInput() {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Consume the invalid input token
            System.out.print("Enter your choice: "); // Reprompt
        }
        return scanner.nextInt();
    }
}